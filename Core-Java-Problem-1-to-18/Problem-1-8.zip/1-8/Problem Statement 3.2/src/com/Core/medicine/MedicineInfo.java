package com.Core.medicine;

public interface MedicineInfo {
	void displayLabel();
}
